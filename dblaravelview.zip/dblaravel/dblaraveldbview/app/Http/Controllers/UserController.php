<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;

class UserController extends Controller
{
    public function showdata(){


$users = DB::table('tbluser')->get();

foreach ($users as $user) {
    echo $user->username;
    echo $user->password;
    echo $user->status;
    echo "<br>";
}


    }

    public function showwhere(){
        $userthat = DB::table('products')->where('name', 'sokhyy')->first();

return $userthat->email;
    }

   public function  showgood(){
    $emaildata = DB::table('products')->where('name', 'sokhy')->value('email');
    echo $emaildata;
   }
   public function showday(){
    $userday = DB::table('products')->find(1);
    return $userday;
   }
   public function data(){

    $titles = DB::table('products')->pluck('title');

foreach ($titles as $title) {
    echo $title;
}

   }
   public function technology(){

    DB::table('usersprodust')->where('active', false)
        ->chunkById(100, function (Collection $users) {
            foreach ($users as $user) {
               DB::table('users')
                    ->where('id', $user->id)
                    ->update(['active' => 0]);

            }
        });


   }
   public function showindex(){
    DB::table('usersprodust')->orderBy('id')->lazy()->each(function (object $user) {
        echo 'hello';
    });
   }


}
